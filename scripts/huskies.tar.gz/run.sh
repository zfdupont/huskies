#!/bin/bash

export DATABASE_URI="mongodb+srv://admin:admin@huskies.fwdwss9.mongodb.net/?retryWrites=true&w=majority"
export HUSKIES_HOME="/Users/zfdupont/huskies-server/scripts"
export TOTAL_PLANS=8
export RECOM_STEPS=20


mkdir -p $HUSKIES_HOME/generated/GA/assignments
mkdir -p $HUSKIES_HOME/generated/GA/preprocess
mkdir -p $HUSKIES_HOME/generated/GA/ensemble
mkdir -p $HUSKIES_HOME/generated/GA/interesting
mkdir -p $HUSKIES_HOME/generated/NY/assignments
mkdir -p $HUSKIES_HOME/generated/NY/preprocess
mkdir -p $HUSKIES_HOME/generated/NY/ensemble
mkdir -p $HUSKIES_HOME/generated/NY/interesting
mkdir -p $HUSKIES_HOME/generated/IL/assignments
mkdir -p $HUSKIES_HOME/generated/IL/preprocess
mkdir -p $HUSKIES_HOME/generated/IL/ensemble
mkdir -p $HUSKIES_HOME/generated/IL/interesting

python -m cProfile -o $HUSKIES_HOME/preprocess.prof preprocess_all.py
python -m cProfile -o $HUSKIES_HOME/generate.prof generate_plans.py
python -m cProfile -o $HUSKIES_HOME/analysis.prof ensemble_analysis.py

